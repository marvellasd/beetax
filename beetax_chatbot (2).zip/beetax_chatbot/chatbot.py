import langchain
import os
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from typing import List
from langchain_core.documents import Document

from sentence_transformers import SentenceTransformer
from langchain_core.embeddings import Embeddings
import torch

class LangchainE5Embedding(Embeddings):
    def __init__(self, model_name="intfloat/multilingual-e5-large", device=None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model = SentenceTransformer(model_name, device=self.device)

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        texts = [f"passage: {text}" for text in texts]
        return self.model.encode(texts, normalize_embeddings=True).tolist()

    def embed_query(self, text: str) -> List[float]:
        return self.model.encode(f"query: {text}", normalize_embeddings=True).tolist()
    
embedding_function = LangchainE5Embedding()

from langchain_chroma import Chroma

vectorstore = Chroma(
    persist_directory="./chroma_e5_database",
    embedding_function=embedding_function,
    collection_name="beetax_collection_v2"
)

from langfuse.openai import OpenAI
import os
from dotenv import load_dotenv
import re
from langfuse import Langfuse
from langfuse.decorators import observe
import csv

load_dotenv(override=True)
langfuse = Langfuse()

api_keys = []
with open("api_key.csv", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        api_keys.append(row["API Key"])

current_key_index = 0
used_attempts = 0

client_llama = OpenAI(
    api_key=api_keys[current_key_index],
    base_url=os.environ["LLAMA_BASE_URL"]
)

def switch_to_next_key():
    global current_key_index, client_llama, used_attempts
    current_key_index = (current_key_index + 1) % len(api_keys)
    used_attempts += 1

    next_key = api_keys[current_key_index]

    client_llama = OpenAI(
        api_key=next_key,
        base_url=os.environ["LLAMA_BASE_URL"]
    )

client_gemini = OpenAI(
    api_key=os.environ["GEMINI_API_KEY"],
    base_url=os.environ["GEMINI_BASE_URL"]
)

@observe(name="llm_rewrite")
def llm_rewrite(messages):
    response = client_gemini.chat.completions.create(
        model="gemini-2.0-flash",
        messages=messages,
        temperature=0.1,
        top_p=0.1)
    return response.choices[0].message.content.strip()

@observe(name="split_user_query")
def split_user_query(user_query, chat_history=None):
    formatted_history = ""
    
    if chat_history:
        formatted_history = "[CHAT HISTORY]\n" + "\n".join(
            f"{msg['role'].capitalize()}: {msg['content']}" for msg in chat_history
        ) + "\n\n"

    system_prompt = """Reformulate and split the following user input into concise, clear, and standalone key phrases in Indonesian. These key phrases should be minimal and representative topics or keywords that capture the core intent of the user's input. Only include phrases that are related to taxation. Do not make up new meanings or interpretations that are not present in the user’s input. If the input contains multiple intents with the same meaning, return only one representative phrase.

Example:
[USER INPUT]
"Halo, mau tanya pajak itu apa sih? kalo pph itu apaan?"
[OUTPUT]
1. Pajak
2. PPh

[USER INPUT]
"Kamu tau pajak ga? Aku mau tanya tentang pph pasal 21."
[OUTPUT]
1. Pajak
2. PPh Pasal 21

[USER INPUT]
"Apa saja yang termasuk objek PPh dan bagaimana hitungnya?"
[OUTPUT]
1. Objek PPh
2. Perhitungan PPh

[USER INPUT]
"Siapa presiden indonesia sekarang dan bagaimana cara lapor SPT tahunan?"
[OUTPUT]
1. Lapor SPT tahunan"""

    user_prompt = (
        f"{formatted_history}"
        f"[USER INPUT]\n{user_query}\n\n"
        f"[OUTPUT]\n1."
    )

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}]

    text = llm_rewrite(messages)

    questions = [
        re.sub(r"^\d+\.\s*", "", line).strip()
        for line in text.split("\n")
        if re.match(r"^\d+\.\s+", line.strip())
    ]

    return questions

@observe(name="retrieve_contexts")
def retrieve_contexts(sub_questions, vectorstore, top_k=3):
    all_docs = []
    
    for sub_q in sub_questions:
        retrieved_docs = vectorstore.similarity_search(sub_q, k=top_k)
        all_docs.extend(retrieved_docs)

    unique_docs = list({doc.page_content: doc for doc in all_docs}.values())

    return unique_docs

@observe(name="build_and_send_prompt")
def build_and_send_prompt(messages):
    global used_attempts
    used_attempts = 0

    while used_attempts < len(api_keys):
        try:
            response = client_llama.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=messages,
                temperature=0.1,
                top_p=0.1,
            )
            return response.choices[0].message.content.strip()

        except Exception as e:
            switch_to_next_key()

    raise Exception("All API keys have been tried and failed.")

def run_chatbot():
    flag = 0
    messages = []

    while True:
        user_input = input("Input: ")
        if user_input.lower() in {"exit", "quit"}:
            break

        chat_history = [{"role": msg["role"], "content": msg["content"]} for msg in messages if msg["role"] in {"user", "assistant"}]
        sub_questions = split_user_query(user_input, chat_history=chat_history)
        results = retrieve_contexts(sub_questions, vectorstore, top_k=3)
        combined_context = "\n\n".join(doc.page_content for doc in results)

        if flag == 0:
            system_prompt = f"""You are a professional tax assistant in Indonesia. Answer the following question in detail based on the [CONTEXT] provided. Do not make up any information that is not present in the [CONTEXT].
            If the question is related to the calculation of PPh 21 (Indonesian income tax), provide a step-by-step breakdown of the calculation systematically. If not, give a relevant explanation based on the [CONTEXT].
            If the question is not related to PPh 21 (Indonesian income tax), clearly state that you cannot answer the question because it is out of scope.
            Always respond in the same language used in the question.
            
[CONTEXT]
{combined_context}"""
            
            messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_input}]

            flag = 1

        else:
            system_prompt = f"""You are a professional tax assistant in Indonesia. Answer the following question in detail based on the [CONTEXT] provided. Do not make up any information that is not present in the [CONTEXT].
            If the question is related to the calculation of PPh 21 (Indonesian income tax), provide a step-by-step breakdown of the calculation systematically. If not, give a relevant explanation based on the [CONTEXT].
            If the question is not related to PPh 21 (Indonesian income tax), clearly state that you cannot answer the question because it is out of scope.
            Always respond in the same language used in the question.

[CONTEXT]
{combined_context}"""
            
            messages[0]["content"] = system_prompt

            messages.append({"role": "user", "content": user_input})

        assistant_response = build_and_send_prompt(messages)
        messages.append({"role": "assistant", "content": assistant_response})

        print("Answer:")
        print(assistant_response)
        print("=" * 80)

run_chatbot()